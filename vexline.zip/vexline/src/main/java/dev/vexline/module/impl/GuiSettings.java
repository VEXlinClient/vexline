package dev.vexline.module.impl;

import dev.vexline.Setting;
import dev.vexline.module.*;

public class GuiSettings extends Module {
    public GuiSettings() {
        super("GUI", "Theme: 0 Vexline Purple, 1 Crimson, 2 Ocean.", Category.MISC);
        add(Setting.num("Theme", 0, 0, 2));
        enabled = true;
    }
}

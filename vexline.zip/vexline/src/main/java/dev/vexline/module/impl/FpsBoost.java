package dev.vexline.module.impl;

import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;

public class FpsBoost extends Module {
    private ParticlesMode particles; private CloudRenderMode clouds; private GraphicsMode graphics;
    private int blend; private double entityScale; private boolean saved;
    public FpsBoost() { super("FPS Boost", "Lowers particles, clouds and graphics detail.", Category.MISC); }
    @Override public void onEnable(MinecraftClient mc) {
        GameOptions o = mc.options;
        particles = o.getParticles().getValue(); clouds = o.getCloudRenderMode().getValue();
        graphics = o.getGraphicsMode().getValue(); blend = o.getBiomeBlendRadius().getValue();
        entityScale = o.getEntityDistanceScaling().getValue(); saved = true;
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityDistanceScaling().setValue(0.75);
    }
    @Override public void onDisable(MinecraftClient mc) {
        if (!saved) return;
        GameOptions o = mc.options;
        o.getParticles().setValue(particles); o.getCloudRenderMode().setValue(clouds);
        o.getGraphicsMode().setValue(graphics); o.getBiomeBlendRadius().setValue(blend);
        o.getEntityDistanceScaling().setValue(entityScale);
    }
}

package dev.vexline.module.impl;

import dev.vexline.Theme;
import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Comparator;
import java.util.List;

public class ModuleListHud extends Module {
    public ModuleListHud() { super("Module List", "Lists enabled modules on screen.", Category.HUD); }
    @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
        List<Module> on = ModuleManager.MODULES.stream()
                .filter(m -> m.enabled && m.category != Category.HUD)
                .sorted(Comparator.comparingInt((Module m) -> -mc.textRenderer.getWidth(m.name))).toList();
        int sw = ctx.getScaledWindowWidth(), y = 4;
        for (Module m : on) {
            int w = mc.textRenderer.getWidth(m.name);
            ctx.fill(sw - w - 10, y, sw - 2, y + 12, 0x90000000);
            ctx.fill(sw - 4, y, sw - 2, y + 12, Theme.accent());
            ctx.drawText(mc.textRenderer, m.name, sw - w - 7, y + 2, Theme.accent(), true);
            y += 12;
        }
    }
}

package dev.vexline.module;

import dev.vexline.module.impl.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    private static boolean applied;

    public static void init() {
        MODULES.add(new Fullbright());
        MODULES.add(new Zoom());
        MODULES.add(new FpsBoost());
        MODULES.add(new SprintToggle());
        MODULES.add(new FpsHud());
        MODULES.add(new CoordsHud());
        MODULES.add(new ModuleListHud());
        MODULES.add(new GuiSettings());
    }

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == c) out.add(m);
        return out;
    }

    public static Module get(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m;
        return null;
    }

    public static void tick(MinecraftClient mc) {
        if (!applied) { // modules enabled from the saved config start on the first tick
            applied = true;
            for (Module m : MODULES) if (m.enabled) m.onEnable(mc);
        }
        for (Module m : MODULES) if (m.enabled) m.onTick(mc);
    }

    public static void hud(DrawContext ctx, MinecraftClient mc) {
        if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;
        for (Module m : MODULES) if (m.enabled) m.onHud(ctx, mc);
    }
}

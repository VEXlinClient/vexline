package dev.vexline.module;

public enum Category {
    RENDER("Render"), MOVEMENT("Movement"), PLAYER("Player"), HUD("HUD"), MISC("Misc");
    public final String label;
    Category(String label) { this.label = label; }
}

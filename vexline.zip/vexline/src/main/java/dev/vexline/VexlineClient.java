package dev.vexline;

import dev.vexline.gui.ClickGuiScreen;
import dev.vexline.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class VexlineClient implements ClientModInitializer {
    public static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vexline.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(net.minecraft.util.Identifier.of("vexline", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ModuleManager.tick(mc);
            while (openGui.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            }
        });
        HudRenderCallback.EVENT.register((ctx, tick) -> ModuleManager.hud(ctx, net.minecraft.client.MinecraftClient.getInstance()));
    }
}

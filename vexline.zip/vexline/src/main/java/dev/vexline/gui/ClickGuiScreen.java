package dev.vexline.gui;

import dev.vexline.Config;
import dev.vexline.Setting;
import dev.vexline.Theme;
import dev.vexline.module.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.*;

public class ClickGuiScreen extends Screen {
    private static final int W = 440, H = 270, SIDE = 104, ROW_H = 22, SET_H = 18;
    private Category selected = Category.RENDER;
    private final Set<Module> expanded = new HashSet<>();

    private record Hit(int x, int y, int w, int h, Module module, Setting setting, Category cat) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private final List<Hit> hits = new ArrayList<>();
    private Hit dragging;

    public ClickGuiScreen() { super(Text.literal("Vexline")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        int x0 = (width - W) / 2, y0 = (height - H) / 2;
        int acc = Theme.accent();

        ctx.fill(0, 0, width, height, 0x66000000);
        ctx.fill(x0 - 1, y0 - 1, x0 + W + 1, y0 + H + 1, Theme.accentDark());
        ctx.fill(x0, y0, x0 + W, y0 + H, Theme.BG);
        ctx.fill(x0, y0, x0 + SIDE, y0 + H, Theme.PANEL);

        ctx.drawText(textRenderer, "VEXLINE", x0 + 12, y0 + 12, acc, true);
        ctx.drawText(textRenderer, "MINECRAFT CLIENT", x0 + 12, y0 + 24, Theme.TEXT_DIM, false);

        int cy = y0 + 46;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            Hit h = new Hit(x0 + 6, cy, SIDE - 12, 22, null, null, c);
            hits.add(h);
            if (sel) ctx.fill(h.x, h.y, h.x + h.w, h.y + h.h, acc);
            else if (h.in(mx, my)) ctx.fill(h.x, h.y, h.x + h.w, h.y + h.h, Theme.ROW_HOVER);
            ctx.drawText(textRenderer, c.label, h.x + 8, h.y + 7, sel ? 0xFFFFFFFF : Theme.TEXT, false);
            cy += 26;
        }
        ctx.drawText(textRenderer, "Theme: " + Theme.name(), x0 + 8, y0 + H - 14, Theme.TEXT_DIM, false);

        int cx = x0 + SIDE + 12, cw = W - SIDE - 24, y = y0 + 12;
        ctx.drawText(textRenderer, selected.label, cx, y, Theme.TEXT, true);
        ctx.drawText(textRenderer, "Left-click: toggle   Right-click: settings", cx + 70, y, Theme.TEXT_DIM, false);
        y += 18;

        for (Module m : ModuleManager.in(selected)) {
            Hit h = new Hit(cx, y, cw, ROW_H, m, null, null);
            hits.add(h);
            ctx.fill(h.x, h.y, h.x + h.w, h.y + h.h, h.in(mx, my) ? Theme.ROW_HOVER : Theme.ROW);
            if (m.enabled) ctx.fill(h.x, h.y, h.x + 3, h.y + h.h, acc);
            ctx.drawText(textRenderer, m.name, h.x + 10, h.y + 3, Theme.TEXT, false);
            ctx.drawText(textRenderer, m.description, h.x + 10, h.y + 12, Theme.TEXT_DIM, false);
            int px = h.x + h.w - 30, py = h.y + 6;
            ctx.fill(px, py, px + 22, py + 10, m.enabled ? acc : 0xFF3B3355);
            ctx.fill(m.enabled ? px + 12 : px + 2, py + 2, m.enabled ? px + 20 : px + 10, py + 8, 0xFFFFFFFF);
            y += ROW_H + 2;

            if (expanded.contains(m)) {
                for (Setting s : m.settings) {
                    Hit sh = new Hit(cx + 8, y, cw - 8, SET_H, m, s, null);
                    hits.add(sh);
                    ctx.fill(sh.x, sh.y, sh.x + sh.w, sh.y + sh.h, 0xFF150E28);
                    if (s.bool) {
                        ctx.drawText(textRenderer, s.name + ": " + (s.getBool() ? "On" : "Off"), sh.x + 8, sh.y + 5, Theme.TEXT, false);
                    } else {
                        double f = (s.value - s.min) / (s.max - s.min);
                        ctx.fill(sh.x, sh.y, sh.x + (int) (sh.w * f), sh.y + sh.h, Theme.accentDark());
                        ctx.drawText(textRenderer, s.name + ": " + (s.max <= 3 ? String.valueOf(s.getInt()) : String.valueOf(s.getInt())), sh.x + 8, sh.y + 5, Theme.TEXT, false);
                    }
                    y += SET_H + 1;
                }
                y += 3;
            }
        }
    }

    private void applySlider(Hit h, double mx) {
        double f = Math.max(0, Math.min(1, (mx - h.x) / h.w));
        h.setting.set(h.setting.min + f * (h.setting.max - h.setting.min));
        if (h.setting.max <= 3) h.setting.set(Math.round(h.setting.value));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();
        for (Hit h : hits) {
            if (!h.in(mx, my)) continue;
            if (h.cat != null) { selected = h.cat; return true; }
            if (h.setting != null) {
                if (h.setting.bool) { h.setting.toggle(); Config.save(); }
                else { dragging = h; applySlider(h, mx); }
                return true;
            }
            if (button == 0) h.module.toggle();
            else if (button == 1 && !h.module.settings.isEmpty()) {
                if (!expanded.remove(h.module)) expanded.add(h.module);
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { applySlider(dragging, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging != null) { dragging = null; Config.save(); return true; }
        return super.mouseReleased(click);
    }
}

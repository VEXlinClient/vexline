package dev.vexline.module.impl;

import dev.vexline.Theme;
import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FpsHud extends Module {
    public FpsHud() { super("FPS", "Shows your frame rate.", Category.HUD); }
    @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
        String t = "FPS: " + mc.getCurrentFps();
        int w = mc.textRenderer.getWidth(t) + 8;
        ctx.fill(4, 4, 4 + w, 17, 0x90000000);
        ctx.fill(4, 4, 6, 17, Theme.accent());
        ctx.drawText(mc.textRenderer, t, 9, 7, Theme.TEXT, true);
    }
}

package dev.vexline.module.impl;

import dev.vexline.Theme;
import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class CoordsHud extends Module {
    public CoordsHud() { super("Coordinates", "Shows your XYZ position.", Category.HUD); }
    @Override public void onHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        String t = String.format("XYZ: %d %d %d", (int) Math.floor(mc.player.getX()), (int) Math.floor(mc.player.getY()), (int) Math.floor(mc.player.getZ()));
        int w = mc.textRenderer.getWidth(t) + 8;
        ctx.fill(4, 20, 4 + w, 33, 0x90000000);
        ctx.fill(4, 20, 6, 33, Theme.accent());
        ctx.drawText(mc.textRenderer, t, 9, 23, Theme.TEXT, true);
    }
}

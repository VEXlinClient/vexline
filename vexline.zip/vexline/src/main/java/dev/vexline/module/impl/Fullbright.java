package dev.vexline.module.impl;

import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.*;

public class Fullbright extends Module {
    public Fullbright() { super("Fullbright", "See clearly in the dark (client-side night vision).", Category.RENDER); }
    @Override public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (cur == null || cur.getDuration() < 600)
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 2000, 0, false, false, false));
    }
    @Override public void onDisable(MinecraftClient mc) {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}

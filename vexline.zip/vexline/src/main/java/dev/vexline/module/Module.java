package dev.vexline.module;

import dev.vexline.Config;
import dev.vexline.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, description;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public int hudY; // used by HUD modules

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }

    protected Setting add(Setting s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (enabled == e) return;
        enabled = e;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e) onEnable(mc); else onDisable(mc);
        Config.save();
    }

    public void onEnable(MinecraftClient mc) {}
    public void onDisable(MinecraftClient mc) {}
    public void onTick(MinecraftClient mc) {}
    public void onHud(DrawContext ctx, MinecraftClient mc) {}
}

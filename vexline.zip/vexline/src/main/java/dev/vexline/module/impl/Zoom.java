package dev.vexline.module.impl;

import dev.vexline.Setting;
import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;

public class Zoom extends Module {
    private final Setting fov = add(Setting.num("Zoom FOV", 30, 30, 70));
    private int previous = -1;
    public Zoom() { super("Zoom", "Narrow your field of view to look far away.", Category.RENDER); }
    @Override public void onEnable(MinecraftClient mc) {
        previous = mc.options.getFov().getValue();
    }
    @Override public void onTick(MinecraftClient mc) { mc.options.getFov().setValue(fov.getInt()); }
    @Override public void onDisable(MinecraftClient mc) {
        if (previous > 0) mc.options.getFov().setValue(previous);
    }
}

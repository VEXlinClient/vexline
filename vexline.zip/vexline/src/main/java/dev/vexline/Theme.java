package dev.vexline;

import dev.vexline.module.ModuleManager;

public class Theme {
    public static final String[] NAMES = {"Vexline Purple", "Crimson", "Ocean"};
    private static final int[] ACCENT = {0xFF8B5CF6, 0xFFEF4444, 0xFF38BDF8};
    private static final int[] ACCENT_DARK = {0xFF5B21B6, 0xFF991B1B, 0xFF0369A1};

    public static final int BG = 0xF0100A1C, PANEL = 0xF0170F2B, ROW = 0xFF1F1538, ROW_HOVER = 0xFF2A1D4A;
    public static final int TEXT = 0xFFEDE9FE, TEXT_DIM = 0xFF9CA3AF;

    private static int idx() {
        var m = ModuleManager.get("GUI");
        return m == null ? 0 : Math.max(0, Math.min(NAMES.length - 1, m.settings.get(0).getInt()));
    }
    public static int accent() { return ACCENT[idx()]; }
    public static int accentDark() { return ACCENT_DARK[idx()]; }
    public static String name() { return NAMES[idx()]; }
}

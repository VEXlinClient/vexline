package dev.vexline.module.impl;

import dev.vexline.module.*;
import net.minecraft.client.MinecraftClient;

public class SprintToggle extends Module {
    public SprintToggle() { super("Toggle Sprint", "Keeps you sprinting while you walk forward.", Category.MOVEMENT); }
    @Override public void onTick(MinecraftClient mc) {
        if (mc.player != null && mc.options.forwardKey.isPressed() && !mc.player.isSneaking())
            mc.options.sprintKey.setPressed(true);
    }
}

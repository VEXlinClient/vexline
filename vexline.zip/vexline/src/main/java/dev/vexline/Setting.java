package dev.vexline;

public class Setting {
    public final String name;
    public final boolean bool;
    public double value, min, max;

    public static Setting bool(String name, boolean def) { return new Setting(name, def ? 1 : 0, 0, 1, true); }
    public static Setting num(String name, double def, double min, double max) { return new Setting(name, def, min, max, false); }

    private Setting(String name, double value, double min, double max, boolean bool) {
        this.name = name; this.value = value; this.min = min; this.max = max; this.bool = bool;
    }

    public boolean getBool() { return value > 0.5; }
    public double get() { return value; }
    public int getInt() { return (int) Math.round(value); }
    public void toggle() { value = getBool() ? 0 : 1; }
    public void set(double v) { value = Math.max(min, Math.min(max, v)); }
}

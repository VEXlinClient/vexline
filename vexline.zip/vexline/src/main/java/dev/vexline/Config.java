package dev.vexline;

import com.google.gson.*;
import dev.vexline.module.Module;
import dev.vexline.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.*;

public class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("vexline.json"); }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : ModuleManager.MODULES) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                for (Setting s : m.settings) o.addProperty(s.name, s.value);
                root.add(m.name, o);
            }
            Files.writeString(path(), GSON.toJson(root));
        } catch (Exception e) { System.err.println("[Vexline] save failed: " + e); }
    }

    public static void load() {
        try {
            if (!Files.exists(path())) return;
            JsonObject root = JsonParser.parseString(Files.readString(path())).getAsJsonObject();
            for (Module m : ModuleManager.MODULES) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                for (Setting s : m.settings) if (o.has(s.name)) s.set(o.get(s.name).getAsDouble());
            }
        } catch (Exception e) { System.err.println("[Vexline] load failed: " + e); }
    }
}
